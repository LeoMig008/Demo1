﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchiffeVersenkenLogik
{
    public enum FeldStatus
    {
        Leer,
        Schiff,
        Getroffen,
        Verfehlt
    }
    public class Spielbrett
    {
        public List<Schiff> Schiffe { get; } = new List<Schiff>();

        public const int Groesse = 10;
        public FeldStatus[,] Cells { get; }

        public Spielbrett()
        {
            Cells = new FeldStatus[Groesse, Groesse];

            for (int  x = 0;  x < Groesse;  x++)
                for (int  y = 0;  y < Groesse;  y++)
                    Cells[x, y] = FeldStatus.Leer;
        }

        public void SetzeSchiff(Schiff schiff, int startX, int startY)
        {
            if (!KannSchiffSetzen(schiff, startX, startY))
                throw new InvalidOperationException("Schiff kann an dieser Position nicht gesetzt werden.");
            schiff.StartX = startX;
            schiff.StartY = startY;
            for (int i = 0; i < schiff.Laenge; i++)
            {
                int x = startX + (schiff.IstHorizontal ? i : 0);
                int y = startY + (schiff.IstHorizontal ? 0 : i);
                Cells[x, y] = FeldStatus.Schiff;
            }
            Schiffe.Add(schiff);
        }

        public bool KannSchiffSetzen(Schiff schiff, int startX, int startY)
        {
            if (schiff == null) return false;

            for (int i = 0; i < schiff.Laenge; i++) 
            {
                int x = startX + (schiff.IstHorizontal ? i : 0);
                int y = startY + (schiff.IstHorizontal ? 0 : i);

                if (x < 0 || x >= Groesse || y < 0 || y >= Groesse)
                    return false;

                if (Cells[x, y] != FeldStatus.Leer)
                    return false;
            }
            return true;
        }




        private void PrüfeKoordinaten(int x, int y)
        {
            if (x < 0 || x >= Groesse || y < 0 || y >= Groesse)
                throw new ArgumentOutOfRangeException(nameof(x), $"Ungültige Koordinaten: x={x}, y={y}. Erwartet 0..{Groesse - 1}.");
        }

        public bool Schiessen(int x, int y)
        {
            PrüfeKoordinaten(x, y);

            foreach (var schiff in Schiffe)
            {
                if (schiff.PositionBelegt(x, y))
                {
                    schiff.TrefferErfassen();
                    Cells[x, y] = FeldStatus.Getroffen;
                    return true;
                }
            }
            Cells[x, y] = FeldStatus.Verfehlt;
            return false;
        }

        public bool AlleSchiffeVersenkt()
        {
            foreach (var schiff in Schiffe)
            {
                if (!schiff.IstVersenkt())
                    return false;
            }
            return true;
        }

        public FeldStatus GetFeldStatus(int x, int y)
        {
            PrüfeKoordinaten(x, y);
            return Cells[x, y];
        }
    }
}
