﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchiffeVersenkenLogik
{
    public class Spielsteuerung
    {
        public Spieler Spieler { get; }
        public Ai Ai { get; }

        private bool SpielerAmZug = true;
        private Random random = new Random();

        public List<int> UebrigeSpielerSchiffe { get; private set; } = new List<int>();

        public Spielsteuerung(string spielerName)
        {
            Spieler = new Spieler(spielerName);
            Ai = new Ai();
        }

        public void StarteSpiel(List<int> schiffLaengen)
        {
            Ai.SchiffeSetzen(schiffLaengen);
            UebrigeSpielerSchiffe = new List<int>(schiffLaengen);
        }


        public bool SpielSetzeSchiff(int laenge, int startX, int startY, bool horizontal)
        {
            if (!UebrigeSpielerSchiffe.Contains(laenge))
            {
                return false;
            }

            Schiff schiff = new Schiff(laenge, horizontal)
            {
                StartX = startX,
                StartY = startY
            };

            if (!Spieler.SpielerBrett.KannSchiffSetzen(schiff, startX, startY))
                return false;

            Spieler.SpielerBrett.SetzeSchiff(schiff, startX, startY);
            UebrigeSpielerSchiffe.Remove(laenge);
            return true;
        }

        public void NächsterZug(int? spielerX = null, int? spielerY = null)
        {
            if (SpielerAmZug)
            {
                if (spielerX.HasValue && spielerY.HasValue)
                {
                    bool treffer = Spieler.Schiessen(Ai.AiBrett, spielerX.Value, spielerY.Value);
                    Console.WriteLine($"Spieler schiesst auf {spielerX}, {spielerY} Treffer: {treffer})");
                    SpielerAmZug = false;
                }
            }
            else
            {
                var zug = Ai.Schiessen(Spieler.SpielerBrett);
                Console.WriteLine($"Computer schiesst auf {zug.x}, {zug.y} Treffer: {zug.treffer}");
                SpielerAmZug = true;
            }
        }

        public bool IstSpielVorbei()
        {
            if (Spieler.HatVerloren())
            {
                Console.WriteLine("Computer gewinnt!");
                return true;
            }
            if (Ai.AiBrett.AlleSchiffeVersenkt())
            {
                Console.WriteLine("Spieler gewinnt!");
                return true;
            }
            return false;
        }
    }
}
