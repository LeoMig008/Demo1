﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchiffeVersenkenLogik
{
    public class Spieler
    {
        public String Name { get; set; }
        public Spielbrett SpielerBrett { get; }
        public Spieler(string name)
        {
            Name = name;
            SpielerBrett = new Spielbrett();
        }

        public bool Schiessen(Spielbrett gegner, int x, int y)
        {
            return gegner.Schiessen(x, y);
        }

        public void SetzeSchiff(Schiff schiff)
        {
            SpielerBrett.SetzeSchiff(schiff, 0, 0);

        }

        public bool HatVerloren()
        {
            return SpielerBrett.AlleSchiffeVersenkt();
        }
    }
}
