﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchiffeVersenkenLogik
{
    public class Schiff
    {
        public int Laenge { get; }
        public int StartX { get; set; }
        public int StartY { get; set; }
        public bool IstHorizontal { get; set; }
        public int Treffer { get; private set; } = 0;

        public Schiff(int laenge, bool istHorizontal)
        {
            Laenge = laenge;
            IstHorizontal = istHorizontal;
        }

        public bool PositionBelegt(int x, int y)
        {
            if (IstHorizontal)
            {
                return y == StartY && x >= StartX && x < StartX + Laenge;
            }
            else
            {
                return x == StartX && y >= StartY && y < StartY + Laenge;
            }
        }
        public void TrefferErfassen()
        {
            Treffer++;
        }
        public bool IstVersenkt()
        {
            return Treffer >= Laenge;
        }
    }
}
