﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchiffeVersenkenLogik
{
    public class Ai
    {
        public string Name { get; set; } = "Computer";
        public Spielbrett AiBrett { get; }
        private Random random = new Random();

        public Ai()
        {
            AiBrett = new Spielbrett();
        }

        public void SchiffeSetzen(List<int> schifflaengen)
        {
            foreach (int laenge in schifflaengen)
            {
                bool gesetzt = false;

                while (!gesetzt)
                {
                    bool horizontal = random.Next(2) == 0;

                    int startX = horizontal ? random.Next(Spielbrett.Groesse - laenge + 1) : random.Next(Spielbrett.Groesse);
                    int startY = horizontal ? random.Next(Spielbrett.Groesse) : random.Next(Spielbrett.Groesse - laenge + 1);

                    Schiff schiff = new Schiff(laenge, horizontal)
                    {
                        StartX = startX,
                        StartY = startY
                    };

                    if (KannSchiffSetzen(schiff))
                    {
                        AiBrett.SetzeSchiff(schiff, schiff.StartX, schiff.StartY);
                        gesetzt = true;
                    }
                }
            }
        }

        private bool KannSchiffSetzen(Schiff schiff)
        {
            for (int i = 0; i < schiff.Laenge; i++)
            {
                int x = schiff.StartX + (schiff.IstHorizontal ? i : 0);
                int y = schiff.StartY + (schiff.IstHorizontal ? 0 : i);
                if (AiBrett.Cells[x, y] != FeldStatus.Leer)
                {
                    return false;
                }
            }
            return true;
        }

        public (int x, int y, bool treffer) Schiessen(Spielbrett gegner)
        {
            int x, y;
            bool ZugOk = false;

            do 
            {
                x = random.Next(Spielbrett.Groesse);
                y = random.Next(Spielbrett.Groesse);

                ZugOk = gegner.Cells[x, y] != FeldStatus.Getroffen &&
                        gegner.Cells[x, y] != FeldStatus.Verfehlt;
            } while (!ZugOk);

            bool treffer = gegner.Schiessen(x, y);
            return (x, y, treffer);
        }
    }
}
