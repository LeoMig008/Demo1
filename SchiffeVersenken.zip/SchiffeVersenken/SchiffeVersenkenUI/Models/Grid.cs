﻿namespace SchiffeVersenkenUI.Models
{
    public class Grid
    {
        public class Square
        {
            public string Id { get; set; }
            public bool Is_Ship { get; set; } 
            public bool Is_Destroyed { get; set; }
            public bool Is_Hit { get; set; }
            public int x { get; set; }
            public int y { get; set; }
        }
    }
}
